//
//  ViewController.swift
//  tableViewSample
//
//  Created by Jeron Thomas on 2017-12-08.
//  Copyright © 2017 AppleInc. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var table: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        
        table.estimatedRowHeight = 100
        table.rowHeight = UITableViewAutomaticDimension
        
    }


}


extension ViewController: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "id", for: indexPath)
        return cell
    }
    
    
}
